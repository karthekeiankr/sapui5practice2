/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"fin/cash/flow/analyzer/controller/MainController"
], function(MainController) {
	"use strict";
	return MainController.extend("fin.cash.flow.analyzer.controller.Worklist_D", {
		
});
});

